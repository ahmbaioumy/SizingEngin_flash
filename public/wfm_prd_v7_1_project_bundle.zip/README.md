# WFM Minimum-HC Sizing & Scheduling Engine (PRD v7.1)

A complete Contact Center Workforce Management (WFM) sizing and scheduling engine built to PRD v7.1 specifications.

## What is inside this ZIP:
1. `wfm_engine_v7_1_standalone.html`: Zero-dependency, offline, single-file HTML version containing the complete engine, test runner, validator, and UI. Double-click to open in any browser.
2. `src/`: Complete TypeScript and React source files for all modules.
3. `samples/`: Benchmark CSV files for Voice FCT, historical demand, and hostile test data.

## Verification
Run tests within the UI or via `npm run lint` and `npm run build`.
All 9 PRD v7.1 Acceptance Cases (Cases 1-9) pass.
